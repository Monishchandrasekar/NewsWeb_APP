from django.apps import AppConfig


class NewswebConfig(AppConfig):
    name = 'newsweb'
