from django.shortcuts import render

# Create your views here.
def home(request):
    import requests
    import json
    api_req=requests.get("http://newsapi.org/v2/everything?domains=wsj.com&apiKey=0c1bd9704cb3456b875b69f37d9e4ed4")
    api=json.loads(api_req.content)
    return render(request,'home.html',{'api':api})
